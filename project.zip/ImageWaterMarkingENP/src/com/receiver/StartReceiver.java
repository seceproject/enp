package com.receiver;

public class StartReceiver {
	public static void main(String args[])
	{
		new Receiver();
		
	}

}
