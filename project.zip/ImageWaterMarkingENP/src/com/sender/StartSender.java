package com.sender;

public class StartSender {
	public static void main(String args[] )
	{
		new Sender();
	}
}
