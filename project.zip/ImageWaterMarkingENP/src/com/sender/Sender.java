package com.sender;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.border.TitledBorder;

import com.stegno.ImagePanel;
import com.stegno.MainClient;
import com.util.AvailableNode;
import com.util.ErrorManager;
import com.util.FileChoose;
import com.util.messageDisplay;



public class Sender {
	private JFrame cryptFrame;
	private JLabel selL;
	private JTextField selFile;
	private JToolBar topTool;
	private JButton sendButton, openButton, encdecButton;
	private JList destList;
	private TitledBorder border;
	private JScrollPane listSrl;
	private String netViewArr[];
	private ArrayList<String> netView;
	private JPanel dispalyPanel;

	public Sender() 
	{
		AvailableNode nodes = new AvailableNode();
		netView = nodes.addAvailNode();
		netViewArr = (String[]) netView.toArray(new String[netView.size()]);

		// send file tool
		cryptFrame = new JFrame("Sender");
		cryptFrame.setLayout(null);
		dispalyPanel=new ImagePanel(new ImageIcon("./Images/comp.jpg").getImage());
		dispalyPanel.setLayout(null);
		dispalyPanel.setBounds(5,5,390, 290);
		cryptFrame.add(dispalyPanel);
		selL = new JLabel("Select Encrypted File");
		selL.setForeground(Color.WHITE);
		selL.setBounds(5,165,120, 40);
		dispalyPanel.add(selL);
		
		selFile = new JTextField();
		selFile.setBounds(135,165,250,30);
		dispalyPanel.add(selFile);
		
		openButton = new JButton("OPEN");
		openButton.setBounds(5,215,120,40);
		dispalyPanel.add(openButton);
		openButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				
				FileChoose fc = new FileChoose();
				selFile.setText(fc.fileSelectionTool());
			}
		});
		
		sendButton = new JButton("SEND");
		sendButton.setBounds(130,215,120, 40);
		dispalyPanel.add(sendButton);
		sendButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
					sendFile();
					//selFile.setText("");
			} 
		});
		

		// Dest List
		border = BorderFactory.createTitledBorder("Select Destination");
		destList = new JList(netViewArr);
		listSrl = new JScrollPane(destList);
		listSrl.setBorder(border);
		listSrl.setBounds(5, 5, 380,150);
		dispalyPanel.add(listSrl);

		// Enc/Dec Button
		encdecButton = new JButton("EmbeddedFile");
		encdecButton.setBounds(255,215,130,40);
		dispalyPanel.add(encdecButton);
		encdecButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				new MainClient();
			}
		});
		
		cryptFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cryptFrame.setSize(400, 300);
		cryptFrame.setVisible(true);
		cryptFrame.setBackground(Color.magenta);
		recieveFile();
	}

	public void sendFile() {
		Thread sndFT = new Thread(new Runnable() {
			public void run() {
				try {
					String sndFileNme = selFile.getText();
					String filNme = sndFileNme;
					StringTokenizer st = new StringTokenizer(sndFileNme, "\\",true);
					while (st.hasMoreTokens()) 
					{
						sndFileNme = st.nextToken();
					}
					Socket conClient = new Socket((String) destList.getSelectedValue(), 2802);
					ObjectOutputStream sf = new ObjectOutputStream(conClient.getOutputStream());
					sf.writeObject(sndFileNme);
					File file = new File(filNme);
					FileInputStream fileIn1 = new FileInputStream(file);
					int len1;
					byte[] buf1 = new byte[1024];
					while ((len1 = fileIn1.read(buf1)) > 0) 
					{
						sf.write(buf1);
					}
					new ErrorManager("File sending completed");
					conClient.close();
					selFile.setText("");
				} catch (UnknownHostException e) {
					new ErrorManager("You have selected invalid System");
				} catch (IOException e) {
					//new ErrorManager(e.toString());
					e.printStackTrace();
				}
			}
		});
		sndFT.start();
	}

	public void recieveFile() {
		Thread filRcvTrd = new Thread(new Runnable() {
			public void run() {
				try {
					do {
						ServerSocket recieve = new ServerSocket(2703);
						Socket rcvSck = recieve.accept();
						ObjectInputStream rcvFile = new ObjectInputStream(
								rcvSck.getInputStream());
						String fileNme = (String) rcvFile.readObject();
						File file = new File(".\\Comp\\ReceiveFiles\\" + fileNme);
						FileOutputStream fileOut = new FileOutputStream(file);
						int buf;
						do 
						{
							buf = rcvFile.read();
							fileOut.write(buf);
						} while (buf != -1);
						fileOut.close();
						rcvSck.close();
						recieve.close();
						String str="File Received";
						new messageDisplay(str);
						
					} while (true);
				} catch (IOException e) {
					//e.printStackTrace();
				} catch (ClassNotFoundException e) {
					//e.printStackTrace();
					e.printStackTrace();
				}
			}
		});
		filRcvTrd.start();
	}
}
